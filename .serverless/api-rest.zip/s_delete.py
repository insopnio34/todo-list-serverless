import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='insopnio34',
    application_name='todo-list-serverless',
    app_uid='SqMrZg9LzY6mL6yXpq',
    org_uid='c96ea9eb-64b7-4c3f-bd0e-cd2b63ebbaac',
    deployment_uid='77c9d123-87b7-4e41-87cb-b719ea10c766',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
